"""
Embeds the complete 39-file repository payload into all notebooks and produces standalone colab setup code.
"""

import os
import io
import zipfile
import base64
import json

def build():
    # 1. Package all src/, configs/, scripts/
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root_dir in ['src', 'configs', 'scripts']:
            for r, d, files in os.walk(root_dir):
                for f in files:
                    if f.endswith('.py') or f.endswith('.yaml') or f.endswith('.json'):
                        fp = os.path.join(r, f)
                        arcname = os.path.relpath(fp, '.')
                        zf.write(fp, arcname)

    data = buf.getvalue()
    b64_str = base64.b64encode(data).decode('ascii')
    
    # Save standalone zip file so user can also download/upload if desired
    with open('firsefile_repo_bundle.zip', 'wb') as f:
        f.write(data)

    setup_cell_code = (
        "# =============================================================================\n"
        "# CELL: Unpack Full FirSeFile ML Codebase into /content\n"
        "# =============================================================================\n"
        "!pip install -q timm transformers scikit-learn pandas seaborn matplotlib pyyaml networkx pillow\n"
        "\n"
        "import os\n"
        "import sys\n"
        "import io\n"
        "import zipfile\n"
        "import base64\n"
        "\n"
        "project_root = \"/content\"\n"
        "if not os.path.exists(project_root):\n"
        "    project_root = os.path.abspath(\".\")\n"
        "\n"
        "bundle_b64 = \"" + b64_str + "\"\n"
        "print(\"Unpacking complete 39-file FirSeFile ML repository into \" + project_root + \"...\")\n"
        "zip_bytes = base64.b64decode(bundle_b64)\n"
        "with zipfile.ZipFile(io.BytesIO(zip_bytes), \"r\") as zf:\n"
        "    zf.extractall(project_root)\n"
        "\n"
        "if project_root not in sys.path:\n"
        "    sys.path.insert(0, project_root)\n"
        "\n"
        "print(\"Successfully unpacked:\")\n"
        "for d in ['src', 'configs', 'scripts']:\n"
        "    p = os.path.join(project_root, d)\n"
        "    if os.path.exists(p):\n"
        "        print(f\"  {d}/: {sorted(os.listdir(p))}\")\n"
        "print(f\"\\n[OK] Repository ready! sys.path includes: {project_root}\")\n"
    )

    # Update 01_byte2image_swin_v2_training.ipynb
    nb_path = 'notebooks/01_byte2image_swin_v2_training.ipynb'
    with open(nb_path, 'r', encoding='utf-8') as f:
        nb = json.load(f)

    # Update Cell 2 with the setup cell code
    for cell in nb['cells']:
        source_text = "".join(cell.get('source', []))
        if 'CELL 2:' in source_text or 'CELL 2' in source_text or '!pip install' in source_text:
            cell['source'] = [setup_cell_code]
            break

    with open(nb_path, 'w', encoding='utf-8') as f:
        json.dump(nb, f, indent=2)

    print(f"[OK] Successfully updated {nb_path} with complete 39-file payload ({len(b64_str):,} chars)!")

if __name__ == "__main__":
    build()
