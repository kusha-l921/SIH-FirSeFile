"""
Script to embed codebase bundle into Colab training notebook for standalone execution.
"""

import os
import io
import zipfile
import base64
import json

def update_notebook():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root_dir in ['src', 'configs']:
            for r, d, files in os.walk(root_dir):
                for f in files:
                    if f.endswith('.py') or f.endswith('.yaml') or f.endswith('.json'):
                        fp = os.path.join(r, f)
                        arcname = os.path.relpath(fp, '.')
                        zf.write(fp, arcname)

    data = buf.getvalue()
    b64_str = base64.b64encode(data).decode('ascii')

    cell_2_code = (
        "# =============================================================================\n"
        "# CELL 2: Install Dependencies & Setup Project Workspace (Auto-Extracts Source)\n"
        "# =============================================================================\n"
        "!pip install -q timm transformers scikit-learn pandas seaborn matplotlib pyyaml networkx\n"
        "\n"
        "import os\n"
        "import sys\n"
        "import io\n"
        "import zipfile\n"
        "import base64\n"
        "\n"
        "# Automatically unpack codebase into Colab environment if not already present\n"
        "if not os.path.exists(\"src\"):\n"
        "    print(\"Unpacking FirSeFile ML source modules into Colab runtime...\")\n"
        f"    bundle_b64 = \"{b64_str}\"\n"
        "    zip_bytes = base64.b64decode(bundle_b64)\n"
        "    with zipfile.ZipFile(io.BytesIO(zip_bytes), \"r\") as zf:\n"
        "        zf.extractall(\".\")\n"
        "    print(\"Successfully unpacked src/ and configs/ into Colab workspace!\")\n"
        "\n"
        "# Ensure project root is in sys.path\n"
        "project_dir = os.path.abspath(\".\")\n"
        "if project_dir not in sys.path:\n"
        "    sys.path.insert(0, project_dir)\n"
        "\n"
        "print(f\"Workspace root: {project_dir}\")\n"
        "print(f\"Modules available in src: {sorted(os.listdir('src'))}\")\n"
    )

    notebooks = [
        'notebooks/01_byte2image_swin_v2_training.ipynb',
        'notebooks/02_graph_reassembly_and_validation.ipynb',
        'notebooks/03_full_pipeline_demo.ipynb',
        'notebooks/04_zero_training_alternative_pipeline.ipynb'
    ]

    for nb_path in notebooks:
        if not os.path.exists(nb_path):
            continue
        with open(nb_path, 'r', encoding='utf-8') as f:
            nb = json.load(f)

        # Find cell 2 or dependency cell
        for cell in nb['cells']:
            if cell['cell_type'] == 'code' and any('pip install' in line or 'CELL 2' in line for line in cell.get('source', [])):
                cell['source'] = [cell_2_code]
                break

        with open(nb_path, 'w', encoding='utf-8') as f:
            json.dump(nb, f, indent=1)
        print(f"[OK] Updated {nb_path} with self-extracting codebase bundle!")

if __name__ == "__main__":
    update_notebook()
